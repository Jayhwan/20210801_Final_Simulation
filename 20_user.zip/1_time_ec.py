import matplotlib.pyplot as plt
import numpy as np
from time_function import *
from indiv_function import *
from scipy.stats import truncnorm

#load = np.load("one_type_load.npy", allow_pickle=True)[:total_user, :time_step]
load = np.load("load_single_low_var.npy", allow_pickle=True)[:total_user, :time_step]
a_o =2*np.random.random((2, time_step)) + 0.5 * np.ones((2, time_step))
tmp = a_o[0]
a_o[0] = np.minimum(a_o[0], a_o[1])
a_o[1] = np.maximum(tmp, a_o[1])
a_o[0] /= 1
np.save("1_a_o_tmp.npy", a_o)
#a_o = np.ones((2, time_step))
a_o = np.load("1_a_o_tmp.npy", allow_pickle=True)[:,:time_step]
_, a_f, data1 = iterations_time(10, time_step, load, a_o)
np.save("1_time_ec_kkt_1_2.npy", data1)
print("##################")
a_o = np.load("1_a_o_tmp.npy", allow_pickle=True)[:,:time_step]
load = np.load("load_single_low_var.npy", allow_pickle=True)[:total_user, :time_step]
a_o, a_f, data2 = iterations_ni_time(10, time_step, load, a_o)
np.save("1_time_ec_ni_1_2.npy", data2)

